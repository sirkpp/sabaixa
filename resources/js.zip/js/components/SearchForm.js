import React from 'react';

const SearchForm=()=>(
  <form>
    <input type="text"/>
    <button>Search</button>
  </form>
);




export default SearchForm;